function jogarSubway() {
    // 1. Esconde o seu menu inicial
    document.getElementById('tela-inicial').style.display = 'none';
    
    // 2. Pega o elemento do iframe
    const jogo = document.getElementById('zona-jogo');
    
    // 3. Coloca o link do jogo de Zurique do seu amigo Tav
    jogo.src = 'https://www.tavvkkj.xyz/zurich/original/index.html';
    
    // 4. Mostra o jogo na tela cheia
    jogo.style.display = 'block';
}
